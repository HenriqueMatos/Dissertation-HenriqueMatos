Manager for all sensors
able to config everything


pagina html