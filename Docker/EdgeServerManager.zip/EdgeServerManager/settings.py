SECRET_KEY = b'Teste2'

SERVER_URL = "http://localhost:8080/auth/"
REALM_NAME = "AppAuthenticator"
CLIENT_ID = "EdgeServer1"
CLIENT_SECRET = "9Wokn60OmIU13WofzyrZzDeKhyIkkvRk"
